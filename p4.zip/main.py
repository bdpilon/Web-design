#project: p4
#submitter: bpilon
#partner: None
#hours:36

#data source:
#https://www.kaggle.com/imoore/2020-us-general-election-turnout-rates
#A graph I would be interested in seeing from my data would be the correlation between the voting rates of voting eleigible people and the percent of voing age people who are voting ineligible.

import pandas as pd
from flask import Flask, request, jsonify, Response
import re
import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
import io
from io import BytesIO

plt.rcParams["font.size"] = 16
matplotlib.use('Agg')

app = Flask(__name__)

df = pd.read_csv('main.csv')
for i in range(len(df['State'])):
    df['VEP Turnout Rate'][i] = float(df['VEP Turnout Rate'][i].replace('%',''))
    df['Prison'][i] = int(df['Prison'][i].replace(',',''))
    df['Total Ballots Counted (Estimate)'][i] = int(df['Total Ballots Counted (Estimate)'][i].replace(',',''))
    df['Voting-Age Population (VAP)'][i] = int(df['Voting-Age Population (VAP)'][i].replace(',',''))
df['VAP Turnout Rate']= df['Total Ballots Counted (Estimate)']/df['Voting-Age Population (VAP)']
df.drop(0)

n = 0
visits = 1
Adono = 0
Bdono = 0

@app.route('/')
def home():
    global visits
    with open("index.html") as f:
        html = f.read()
    if visits<=10:
        if visits%2 == 0:
            visits+=1
            html = re.sub(r"red", "blue", html)
            html = re.sub(r"from=B", "from=A", html)
            return html
        if visits%2 == 1:
            visits+=1
            html = re.sub(r"blue", "red", html)
            html = re.sub(r"from=A", "from=B", html)
            return html
    else:
        if Adono>Bdono:
            html = re.sub(r"red", "blue", html)
            html = re.sub(r"from=B", "from=A", html)
            return html
        else:
            html = re.sub(r"blue", "red", html)
            html = re.sub(r"from=A", "from=B", html)
            return html
            

@app.route('/browse.html')
def browse():
    df = pd.read_csv('main.csv')
    for i in range(len(df['State'])):
        df['VEP Turnout Rate'][i] = float(df['VEP Turnout Rate'][i].replace('%',''))
        df['Prison'][i] = int(df['Prison'][i].replace(',',''))
        df['Total Ballots Counted (Estimate)'][i] = int(df['Total Ballots Counted (Estimate)'][i].replace(',',''))
        df['Voting-Age Population (VAP)'][i] = int(df['Voting-Age Population (VAP)'][i].replace(',',''))
    df['VAP Turnout Rate']= df['Total Ballots Counted (Estimate)']/df['Voting-Age Population (VAP)']
    table = df.to_html()
    html = "<html><body><h1>The Data</h1>{}</body></html>"
    return html.format(table)

@app.route('/email', methods=["POST"])
def email():
    global n
    email = str(request.data, "utf-8")
    if re.match(r"^[^@]+@[^@]+\.", email): # 1
        n+=1
        with open("emails.txt", "a") as f: # open file in append mode
            f.write(email + '\n') # 2
        return jsonify("thanks, you're subscriber number {}!".format(n))
    return jsonify("please try another email, the one you entered is not valid")

@app.route('/donate.html')
def donate():
    global Bdono
    global Adono
    with open("donate.html") as f:
        html = f.read()
        AorB = request.args["from"]
        if AorB =='B':
            Bdono +=1
        if AorB == 'A':
            Adono +=1
    return html

@app.route("/dashboard1.svg")
def dash1():
    data = request.args["Data"]
    fig, ax = plt.subplots(figsize=(3,1.5))
    ax = df.plot.scatter(x = 'Prison' , y=data +' Turnout Rate')
    ax.set_xlabel("Prison Population")
    ax.set_ylabel(data +' Turnout Rate')
    plt.xticks(rotation = 45)
    fake_file = BytesIO()
    ax.get_figure().savefig(fake_file, format="svg", bbox_inches="tight")
    plt.close(fig)
    return Response(fake_file.getvalue(),
                    headers={"Content-Type": "image/svg+xml"})

@app.route("/dashboard2.svg")
def States():
    fig, ax = plt.subplots(figsize=(3,1.5))
    ax = df.plot.bar(x = 'State' , y='Prison',legend=False)
    ax.set_xlabel('State')
    ax.set_ylabel("Prison Population")
    fake_file = BytesIO()
    ax.get_figure().savefig(fake_file, format="svg", bbox_inches="tight")
    plt.close(fig)
    return Response(fake_file.getvalue(),
                    headers={"Content-Type": "image/svg+xml"})

if __name__ == '__main__':
    app.run(host="0.0.0.0", debug=True, threaded=False) # don't change this line!

# NOTE: app.run never returns (it runs for ever, unless you kill the process)
# Thus, don't define any functions after the app.run call, because it will
# never get that far.